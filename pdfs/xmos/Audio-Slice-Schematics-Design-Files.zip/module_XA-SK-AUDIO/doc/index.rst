XA-SK-AUDIO Slice Cadr hardware Guide
-------------------------------------

.. toctree::

   overview.rst
   pinout.rst


